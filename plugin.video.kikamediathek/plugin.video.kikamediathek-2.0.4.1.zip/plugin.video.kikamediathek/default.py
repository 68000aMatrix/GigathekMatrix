﻿# -*- coding: utf-8 -*-
import libkika

libkika.list()