﻿# -*- coding: utf-8 -*-
import libwdr

libwdr.list()